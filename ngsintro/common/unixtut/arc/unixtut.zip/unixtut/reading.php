<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Recommended UNIX Books</title>
<link href="unixtut2.css" rel="stylesheet" type="text/css" />
<link href="unixtut2-print.css" rel="stylesheet" type="text/css" media="print" />
</head>
<body>
<div id="container">
  <h1>Recommended UNIX Books </h1>
  <table align="center" cellpadding="8" cellspacing="0" bordercolor="#666666">
    <tr>
      <td valign="top" bgcolor="#F9FAFF"><h4><a href="http://www.amazon.co.uk/gp/product/0596003307?ie=UTF8&amp;tag=unixtutorialf-21&amp;linkCode=as2&amp;camp=1634&amp;creative=6738&amp;creativeASIN=0596003307">Unix Power Tools</a><img src="http://www.assoc-amazon.co.uk/e/ir?t=unixtutorialf-21&l=as2&o=2&a=0596003307" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />        </h4>
      <p><a href="http://www.amazon.co.uk/gp/product/0596003307?ie=UTF8&tag=unixtutorialf-21&linkCode=as2&camp=1634&creative=6738&creativeASIN=0596003307"><img src="http://images.amazon.com/images/P/0596003307.01._AA_SCTZZZZZZZ_.jpg" alt="Unix Power Tools" hspace="12" border="0" align="right" /></a>If you only buy one UNIX book, then this is it. Affectionately referred to by readers as &quot;<b>the</b>&quot; Unix book, <a href="http://www.amazon.co.uk/gp/product/0596003307?ie=UTF8&amp;tag=unixtutorialf-21&amp;linkCode=as2&amp;camp=1634&amp;creative=6738&amp;creativeASIN=0596003307">UNIX Power Tools</a> provides access to information every Unix user is going to need to know. It will help you think creatively about UNIX, and will help you get to the point where you can analyse your own problems.</p>
        <p>Whether you are a newcomer or a Unix power user, you'll find yourself thumbing through the goldmine of information in the new edition of <em>Unix Power Tools</em> to add to your store of knowledge. Want to try something new? Check this book first, and you're sure to find a tip or trick that will prevent you from learning things the hard way. </p>
        <p>The latest edition of this best-selling favorite is loaded with advice about almost every aspect of Unix, covering all the new technologies that users need to know. In addition to vital information on Linux, Darwin, and BSD, <em>Unix Power Tools</em> 3rd Edition now offers more coverage of bash, zsh, and other new shells, along with discussions about modern utilities and applications.</p>      </td>
    </tr>
    <tr>
      <td valign="top" bgcolor="#FFFFF0"><h4><a href="http://www.amazon.co.uk/gp/product/1593271182?ie=UTF8&tag=unixtutorialf-21&linkCode=as2&camp=1634&creative=6738&creativeASIN=1593271182">Ubuntu Linux for Non-geeks</a></h4>
      <p><a href="http://www.amazon.co.uk/gp/product/1593271182?ie=UTF8&tag=unixtutorialf-21&linkCode=as2&camp=1634&creative=6738&creativeASIN=1593271182"><img src="http://images.amazon.com/images/P/1593271182.01._AA_SCTZZZZZZZ_V37019604_.jpg" hspace="15" border="0" align="right"></a><img src="http://www.assoc-amazon.co.uk/e/ir?t=unixtutorialf-21&l=as2&o=2&a=1593271182" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" /></a>What to find out about Linux, but  not sure where to start? This book may be the answer. Ubuntu has been hailed as the Linux distribution that will really get newbies  feeling comfortable and confident using Linux.</p>
        <p>Written in an informal, conversational style, it is perfect for non-technical users who would like to start installing and using Linux on their PC. Full of tips, tricks, and helpful pointers, <a href="http://www.amazon.co.uk/gp/product/1593271182?ie=UTF8&tag=unixtutorialf-21&linkCode=as2&camp=1634&creative=6738&creativeASIN=1593271182">Ubuntu Linux for Non-geeks</a><img src="http://www.assoc-amazon.co.uk/e/ir?t=unixtutorialf-21&l=as2&o=2&a=1593271182" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" /> is a hands-on, project-based, take-it-slow guidebook intended for those  interested in--but nervous about--switching to the Linux operating  system. Step-by-step projects build upon earlier tutorial concepts,  helping you absorb and apply what you've learned.</p>
        <p>It  covers all the topics likely to be of interest to an average  desktop user, such as installing new software; Internet  connectivity; working with  printers,   scanners, and removable storage devices; and handling DVDs, audio files, and even iPods.</p>        </td>
    </tr>

    <tr>
      <td valign="top" bgcolor="#FFF4F4"><h4><a href="http://www.amazon.co.uk/gp/product/0596100299?ie=UTF8&amp;tag=unixtutorialf-21&amp;linkCode=as2&amp;camp=1634&amp;creative=6738&amp;creativeASIN=0596100299"><b>Unix in a Nutshell</b></a></h4>
      <p><a href="http://www.amazon.co.uk/gp/product/0596100299?ie=UTF8&amp;tag=unixtutorialf-21&amp;linkCode=as2&amp;camp=1634&amp;creative=6738&amp;creativeASIN=0596100299"><img src="http://images.amazon.com/images/P/0596100299.02._AA_SCTZZZZZZZ_.jpg" alt="Unix in a Nutshell" width="74" height="110" hspace="12" border="0" align="right" /></a>This quick reference has been reworked to present you with the current state of Unix. <a href="http://www.amazon.co.uk/gp/product/0596100299?ie=UTF8&amp;tag=unixtutorialf-21&amp;linkCode=as2&amp;camp=1634&amp;creative=6738&amp;creativeASIN=0596100299">Unix in a Nutshell</a>  features chapter overviews, in-depth command coverage, and specific examples, it's the perfect supplement for Unix users and programmers. </p>
	  <p>The latest edition of this bestselling reference brings Unix up-to-date. It's been reworked to keep current with the broader state of Unix in today's world and highlight the strengths of this operating system in all its various flavors.</p>
	  <p> New topics include package management programs, source code management systems, and the Solaris 10, GNU/Linux, and Mac OS X systems.</p></td>
    </tr>
    <tr>
      <td valign="top" bgcolor="#F0FEFF"><h4><a href="http://www.amazon.co.uk/gp/product/0596003439?ie=UTF8&amp;tag=unixtutorialf-21&amp;linkCode=as2&amp;camp=1634&amp;creative=6738&amp;creativeASIN=0596003439"><strong>Essential System Administration</strong></a></h4>
      <p><a href="http://www.amazon.co.uk/gp/product/0596003439?ie=UTF8&amp;tag=unixtutorialf-21&amp;linkCode=as2&amp;camp=1634&amp;creative=6738&amp;creativeASIN=0596003439"><img src="http://images.amazon.com/images/P/0596003439.01._AA_SCTZZZZZZZ_.jpg" alt="Essential Systems Administration" width="82" height="110" hspace="12" border="0" align="right" /></a>This is the book I used to learn UNIX System Administration.</p>
        <p><a href="http://www.amazon.co.uk/gp/product/0596003439?ie=UTF8&amp;tag=unixtutorialf-21&amp;linkCode=as2&amp;camp=1634&amp;creative=6738&amp;creativeASIN=0596003439">Essential System Administration,3rd Edition</a> is the definitive guide for Unix system administration. It provides a clear, concise, practical guide to the real-world issues that anyone responsible for a Unix system faces daily.</p>
      <p>The new edition of this indispensable reference has been fully updated for all the latest operating systems. It describes all the usual administrative tools that Unix provides, but it also shows how to use them intelligently and efficiently.</p></td>
    </tr>
    <tr>
      <td valign="top" bgcolor="#FFF4FD"><h4><a href="http://www.amazon.co.uk/gp/product/0596005954?ie=UTF8&tag=unixtutorialf-21&linkCode=as2&camp=1634&creative=6738&creativeASIN=0596005954">Classic Shell Scripting</a><img src="http://www.assoc-amazon.co.uk/e/ir?t=unixtutorialf-21&l=as2&o=2&a=0596005954" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" /><img src="http://www.assoc-amazon.co.uk/e/ir?t=unixtutorialf-21&l=as2&o=2&a=0596005954" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" /></h4>
      <p><a href="http://www.amazon.co.uk/gp/product/0596005954?ie=UTF8&tag=unixtutorialf-21&linkCode=as2&camp=1634&creative=6738&creativeASIN=0596005954"><img src="http://images.amazon.com/images/P/0596005954.02._AA_SCTZZZZZZZ_.jpg" alt="Shell Scripting" width="84" height="110" hspace="12" border="0" align="right" /></a>Shell scripting is essential for Unix users -  the shell  unlocks the real potential of Unix. It's a way to quickly harness and customize the full power of any Unix system. With shell scripts, you can combine the fundamental Unix text and file processing commands to crunch data and automate repetitive tasks. But beneath this simple promise lies a treacherous ocean of variations in Unix commands and standards. <a href="http://www.amazon.co.uk/gp/product/0596005954?ie=UTF8&amp;tag=unixtutorialf-21&amp;linkCode=as2&amp;camp=1634&amp;creative=6738&amp;creativeASIN=0596005954">Classic Shell Scripting</a> is written to help you reliably navigate these tricky waters. </p>
      <p>Writing shell scripts requires more than just a knowledge of the shell language, it also requires familiarity with the individual Unix programs: why each one is there, how to use them by themselves, and in combination with the other programs. The authors are intimately familiar with the tips and tricks that can be used to create excellent scripts, as well as the traps that can make your best effort a bad shell script. With Classic Shell Scripting you'll avoid hours of wasted effort. You'll learn not only write useful shell scripts, but how to do it properly and portably.</p>        </td>
    </tr>
    <tr>
      <td valign="top" bgcolor="#FFF8F5"><h4><a href="http://astore.amazon.co.uk/unixtutorialf-21">More Recommended Books</a></h4>
      <p> A full list of <a href="http://astore.amazon.co.uk/unixtutorialf-21">other Unix and Linux books</a> you may find useful are available at Amazon.  </p>
      <p>&nbsp;</p>
      <p align="center"><iframe src="http://rcm-uk.amazon.co.uk/e/cm?t=unixtutorialf-21&o=2&p=26&l=ur1&category=gift_certificates&banner=0ZS2J1W4F5KNEBHAKWR2&f=ifr" width="468" height="60" scrolling="no" border="0" marginwidth="0" style="border:none;" frameborder="0"></iframe></p>	  </td>
    </tr>
  </table>
  <p class="date"> <a href="http://www.ee.surrey.ac.uk/Personal/M.Stonebank/">M.Stonebank@surrey.ac.uk</a></p>
</div>
</body>
</html>
